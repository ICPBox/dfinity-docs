# 对于协议极客 (for protocol enthusiasts)

`Internet Computer`是由ICP（Internet Computer Protocol）议创建的。Internet Computer是自治的、并且能够按照需求进行自增长。Internet Computer是由分布在世界各地的数据中心上面跑的特制的节点机组成的。和所有其他的公链一样，它是不可停止的，跑在Internet Computer上面的智能合约也是放篡改的。

查看下面的资源以深入了解ICP！

- 教程库，是我们这个世界一流的团队制作的关于ICP的技术视频，无价之宝：
 - Chain Key加密技术，一个突破性技术，它允许Internet Computer扩展到数以百万计的节点规模。最值得说的就是这个Chain Key的技术创新，它使得Internet Computer只有简单的一个公钥，所以就算是智能手表、手机都能轻易地认证Internet Computer的公钥。
- 接口文档，完全的技术文档，介绍Internet Computer的整个底层接口。
- Internet Computer面板，可以实时查看Internet Computer区块链的指标信息。